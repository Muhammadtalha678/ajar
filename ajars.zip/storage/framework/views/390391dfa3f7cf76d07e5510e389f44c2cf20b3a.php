
<!DOCTYPE html>
<html>
    <head>
        <title>Ajar Login Page</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
        <link rel="stylesheet" href="/style1.css">
    </head>
    <body class="bgcolor">
        
        <div class="container">
            <br><br><br><br><br>
            <div class="row">
                <div class="col-sm-1"></div>
                <div class="col-sm-5">
                    <h1 class="changecolor">ajar</h1>
                    <p class="changetext">Place Holder Text</p>
                </div>
                <div class="col-sm-5">
                    <div class="card loginbox container">
                        <form method="POST" action="<?php echo e(route('login')); ?>">
                                   <?php echo csrf_field(); ?>
                            
                            <div class="mb-3">
                                <input class="form-control form-control-lg myinputbox  <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="exampleFormControlInput1" placeholder="Email address or phone number" type="email" name="email" :value="old('email')" required autofocus>
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                  <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="mb-3">
                                <input class="form-control form-control-lg myinputbox <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="exampleFormControlInput1" placeholder="Password " type="password" name="password" required autocomplete="current-password" :value="__('Password')" >
                            </div>
                            <div class="d-grid gap-2">
                                <button class="btn btn-primary mybuttonbox" type="submit">Login</button>
                            </div>
                        </form>
                        <a href="<?php echo e(route('password.request')); ?>"><P class="text-center">Forgotten Password</P></a>
                        <hr>
                        <div class="d-grid gap-2 col-6 mx-auto">
                            <a href="<?php echo e(route('register')); ?>"><button class="btn btn-success mybuttonbox2" type="button">
                            Create New Account</button></a>
                            
                        </div>
                        
                    </div>
                    <br>
                    <p class="text-center">Place Holder Text</p>
                </div>
                
                <div class="col-sm-1"></div>
            </div>
        </div>
    </body>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</html><?php /**PATH E:\xampp\htdocs\ajars\resources\views/auth/login.blade.php ENDPATH**/ ?>