<?php echo e($slot); ?>

<?php /**PATH E:\xampp\htdocs\ajars\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>