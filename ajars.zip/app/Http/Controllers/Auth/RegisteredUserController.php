<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Providers\RouteServiceProvider;
use Illuminate\Auth\Events\Registered;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rules;
use Twilio\Rest\Client;
class RegisteredUserController extends Controller
{
    /**
     * Display the registration view.
     *
     * @return \Illuminate\View\View
     */
    public function create()
    {
        return view('auth.register');
    }

    /**
     * Handle an incoming registration request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\RedirectResponse
     *
     * @throws \Illuminate\Validation\ValidationException
     */
    public function store(Request $request)
    {
        $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'unique:users'],
            'password' => ['required', 'confirmed', Rules\Password::defaults()],
        ]);
        if (is_numeric($request->email)) {
            $token = getenv("TWILIO_AUTH_TOKEN");
                   $twilio_sid = getenv("TWILIO_SID");
                   $twilio_verify_sid = getenv("TWILIO_VERIFY_SID");
                   $twilio = new Client($twilio_sid, $token);
                   $twilio->verify->v2->services($twilio_verify_sid)
                       ->verifications
                       ->create($request->email, "sms");
            $user = User::create([
            'name' => $request->name,
            'email' => $request->email,
            'password' => Hash::make($request->password),
        ]);
            // Auth::login($user);
        return redirect()->route('verifysms')->with(['phone' => $request->email]);

        }
        
            $user = User::create([
            'name' => $request->name,
            'email' => $request->email,
            'password' => Hash::make($request->password),
        ]);

        event(new Registered($user));

        Auth::login($user);
        
        

        return redirect(RouteServiceProvider::HOME);
    }
    public function verifysms()
    {
        return view('auth.verify');
    }
    public function verifysmsno(Request $request)
    {
         $data = $request->validate([
            'verification_code' => ['required', 'numeric'],
            'phone' => ['required', 'string'],
        ]);
         $token = getenv("TWILIO_AUTH_TOKEN");
        $twilio_sid = getenv("TWILIO_SID");
        $twilio_verify_sid = getenv("TWILIO_VERIFY_SID");
        $twilio = new Client($twilio_sid, $token);
        $verification = $twilio->verify->v2->services($twilio_verify_sid)
            ->verificationChecks->create(['code' => $data['verification_code'], 'to' => $data['phone']]);
        if ($verification->valid) {
            var_dump($verification->valid);exit();
            $user = tap(User::where('email', $request->email))->update(['email_verified_at' => "true"]);
            /* Authenticate user */
            // Auth::login($user->first());
            return redirect()->route('dashboardajar')->with(['message' => 'Phone number verified']);
        }
        return back()->with(['phone' => $data['phone'], 'error' => 'Invalid verification code entered!']);
    }
}
